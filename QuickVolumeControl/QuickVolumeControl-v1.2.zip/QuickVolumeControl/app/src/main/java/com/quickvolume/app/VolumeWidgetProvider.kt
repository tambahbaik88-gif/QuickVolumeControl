package com.quickvolume.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.TypedValue
import android.widget.RemoteViews
import android.widget.Toast

class VolumeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, buildViews(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val result = when (intent.action) {
            ACTION_MODE -> {
                val mode = VolumeMode.values().firstOrNull { it.name == intent.getStringExtra(EXTRA_MODE) }
                    ?: return
                VolumeController.apply(context, mode)
            }
            ACTION_BRIGHTNESS -> BrightnessController.setTarget(context)
            ACTION_LIVE -> ScreenLive.toggle(context)
            else -> return
        }
        refreshAll(context)
        Toast.makeText(context.applicationContext, result.message, Toast.LENGTH_LONG).show()
    }

    companion object {
        const val ACTION_MODE = "com.quickvolume.app.ACTION_MODE"
        const val ACTION_BRIGHTNESS = "com.quickvolume.app.ACTION_BRIGHTNESS"
        const val ACTION_LIVE = "com.quickvolume.app.ACTION_LIVE"
        const val EXTRA_MODE = "mode"

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, VolumeWidgetProvider::class.java))
            for (id in ids) mgr.updateAppWidget(id, buildViews(context))
        }

        private fun style(
            v: RemoteViews, id: Int, on: Boolean,
            emoji: String, label: String, bgOff: Int, bgOn: Int,
        ) {
            v.setInt(id, "setBackgroundResource", if (on) bgOn else bgOff)
            v.setTextViewText(id, if (on) "$emoji\n$label ✓" else "$emoji\n$label")
            v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, if (on) 15f else 12f)
        }

        private fun buildViews(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_volume)
            val active = VolumeController.activeMode(context)
            val live = ScreenLive.isOn(context)

            style(v, R.id.btn_normal, active == VolumeMode.NORMAL, "🔊", "Normal", R.drawable.btn_normal, R.drawable.btn_normal_on)
            style(v, R.id.btn_silent, active == VolumeMode.SILENT, "🤫", "Silent", R.drawable.btn_silent, R.drawable.btn_silent_on)
            style(v, R.id.btn_loud, active == VolumeMode.LOUD, "🌙", "Loud", R.drawable.btn_loud, R.drawable.btn_loud_on)
            style(v, R.id.btn_mute, active == VolumeMode.MUTE, "🔇", "Mute", R.drawable.btn_mute, R.drawable.btn_mute_on)
            style(v, R.id.btn_live, live, "📺", "Live", R.drawable.btn_live, R.drawable.btn_live_on)

            v.setTextViewText(R.id.btn_bright, "☀\n${BrightnessController.targetPercent(context)}%")
            v.setOnClickPendingIntent(R.id.btn_normal, modeIntent(context, VolumeMode.NORMAL, 1))
            v.setOnClickPendingIntent(R.id.btn_silent, modeIntent(context, VolumeMode.SILENT, 2))
            v.setOnClickPendingIntent(R.id.btn_loud, modeIntent(context, VolumeMode.LOUD, 3))
            v.setOnClickPendingIntent(R.id.btn_mute, modeIntent(context, VolumeMode.MUTE, 5))
            v.setOnClickPendingIntent(R.id.btn_bright, action(context, ACTION_BRIGHTNESS, 4))
            v.setOnClickPendingIntent(R.id.btn_live, action(context, ACTION_LIVE, 6))
            return v
        }

        private fun modeIntent(context: Context, mode: VolumeMode, code: Int): PendingIntent {
            val i = Intent(context, VolumeWidgetProvider::class.java)
                .setAction(ACTION_MODE)
                .putExtra(EXTRA_MODE, mode.name)
            return broadcast(context, code, i)
        }

        private fun action(context: Context, action: String, code: Int): PendingIntent =
            broadcast(context, code, Intent(context, VolumeWidgetProvider::class.java).setAction(action))

        private fun broadcast(context: Context, code: Int, intent: Intent): PendingIntent =
            PendingIntent.getBroadcast(
                context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
    }
}
