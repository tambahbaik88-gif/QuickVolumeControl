package com.quickvolume.app

import android.content.Context
import android.provider.Settings

/** Layar selalu menyala dengan mengatur batas waktu layar mati ke nilai maksimum. */
object ScreenLive {
    private const val FOREVER = Int.MAX_VALUE
    private const val ONE_HOUR = 3_600_000
    private const val DEFAULT_TIMEOUT = 120_000

    private fun prefs(c: Context) = c.getSharedPreferences("qvc", Context.MODE_PRIVATE)

    private fun timeout(c: Context) =
        Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, DEFAULT_TIMEOUT)

    fun isOn(c: Context) = prefs(c).getBoolean("live", false) && timeout(c) >= ONE_HOUR

    fun toggle(c: Context): ApplyResult {
        if (!Settings.System.canWrite(c)) {
            return ApplyResult(false, "Screen Live belum aktif: izin ubah pengaturan sistem belum diberikan.")
        }
        val result = try {
            if (isOn(c)) {
                val saved = prefs(c).getInt("saved_timeout", DEFAULT_TIMEOUT)
                val restore = if (saved >= ONE_HOUR) DEFAULT_TIMEOUT else saved
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, restore)
                prefs(c).edit().putBoolean("live", false).apply()
                ApplyResult(true, "Screen Live dimatikan. Layar kembali padam otomatis.")
            } else {
                prefs(c).edit()
                    .putInt("saved_timeout", timeout(c))
                    .putBoolean("live", true)
                    .apply()
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, FOREVER)
                if (timeout(c) >= ONE_HOUR) {
                    ApplyResult(true, "Screen Live aktif: layar akan selalu menyala (baterai lebih boros).")
                } else {
                    prefs(c).edit().putBoolean("live", false).apply()
                    ApplyResult(false, "Perangkat ini membatasi waktu layar, Screen Live tidak bisa aktif penuh.")
                }
            }
        } catch (e: SecurityException) {
            ApplyResult(false, "Screen Live ditolak oleh sistem.")
        }
        VolumeWidgetProvider.refreshAll(c)
        return result
    }
}
