package com.quickvolume.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menyalakan kembali penjaga kecerahan setelah perangkat restart. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (BrightnessGuardService.isEnabled(context) && BrightnessController.canWrite(context)) {
            try {
                BrightnessGuardService.start(context)
            } catch (e: Exception) {
                // Sistem menolak memulai layanan latar depan; pengguna bisa menyalakannya dari aplikasi.
            }
        }
    }
}
