package com.quickvolume.app

import android.content.Context
import android.provider.Settings
import kotlin.math.roundToInt

object BrightnessController {
    const val MAX = 255
    const val DEFAULT_PERCENT = 50
    const val MIN_PERCENT = 10
    const val MAX_PERCENT = 90
    private const val KEY = "bright_target_pct"

    fun canWrite(context: Context) = Settings.System.canWrite(context)

    private fun prefs(c: Context) = c.getSharedPreferences("qvc", Context.MODE_PRIVATE)

    fun targetPercent(c: Context): Int =
        prefs(c).getInt(KEY, DEFAULT_PERCENT).coerceIn(MIN_PERCENT, MAX_PERCENT)

    fun setTargetPercent(c: Context, pct: Int) {
        prefs(c).edit().putInt(KEY, pct.coerceIn(MIN_PERCENT, MAX_PERCENT)).apply()
        VolumeWidgetProvider.refreshAll(c)
    }

    fun target(c: Context): Int = (targetPercent(c) * MAX / 100f).roundToInt()

    fun current(context: Context): Int = try {
        Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
    } catch (e: Settings.SettingNotFoundException) {
        target(context)
    }

    fun currentPercent(context: Context) = (current(context) * 100f / MAX).roundToInt()

    fun setTarget(context: Context): ApplyResult {
        if (!canWrite(context)) {
            return ApplyResult(false, "Kecerahan belum diubah: izin ubah pengaturan sistem belum diberikan.")
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
            )
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, target(context))
            ApplyResult(true, "Kecerahan diatur ke ${targetPercent(context)}%.")
        } catch (e: SecurityException) {
            ApplyResult(false, "Kecerahan ditolak oleh sistem.")
        }
    }
}
