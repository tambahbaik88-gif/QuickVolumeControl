package com.quickvolume.app

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings

/** Android tidak mengizinkan app biasa menyalakan fitur ini; jadi buka panel sistemnya, lalu widget disinkronkan. */
class SystemToggleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val action = when (intent.getStringExtra("which")) {
            "air" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "loc" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_BLUETOOTH_SETTINGS
        }
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
            }
        }
        scheduleRefresh(this)
        finish()
    }

    private fun scheduleRefresh(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val delays = longArrayOf(5000, 12000, 25000, 50000)
        for ((i, d) in delays.withIndex()) {
            val pi = PendingIntent.getBroadcast(
                context, 100 + i,
                Intent(context, VolumeWidgetProvider::class.java).setAction(VolumeWidgetProvider.ACTION_REFRESH),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + d, pi)
        }
    }
}
