package com.quickvolume.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

class VolumeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, buildViews(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val result = when (intent.action) {
            ACTION_REFRESH, Intent.ACTION_AIRPLANE_MODE_CHANGED, "android.location.MODE_CHANGED", "android.bluetooth.adapter.action.STATE_CHANGED" -> { refreshAll(context); return }
            ACTION_MODE -> {
                val mode = VolumeMode.values().firstOrNull { it.name == intent.getStringExtra(EXTRA_MODE) }
                    ?: return
                VolumeController.applyTimed(context, mode)
            }
            ACTION_BRIGHTNESS -> BrightnessController.setTargetTimed(context)
            ACTION_LIVE -> ScreenLive.toggleTimed(context)
            else -> return
        }
        refreshAll(context)
        Toast.makeText(context.applicationContext, result.message, Toast.LENGTH_LONG).show()
    }

    companion object {
        const val ACTION_MODE = "com.quickvolume.app.ACTION_MODE"
        const val ACTION_BRIGHTNESS = "com.quickvolume.app.ACTION_BRIGHTNESS"
        const val ACTION_LIVE = "com.quickvolume.app.ACTION_LIVE"
        const val EXTRA_MODE = "mode"
        const val ACTION_REFRESH = "com.quickvolume.app.ACTION_REFRESH"

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, VolumeWidgetProvider::class.java))
            for (id in ids) mgr.updateAppWidget(id, buildViews(context))
        }

        private const val OFF_COLOR = 0xFF9AA3B5.toInt()
        private const val ON_COLOR = 0xFFFFFFFF.toInt()
        private const val SUN_COLOR = 0xFFFFC857.toInt()

        /** Satu gaya seragam: ukuran tetap, aktif = warna penuh + ikon putih, nonaktif = gelap + ikon abu. */
        private fun tile(
            v: RemoteViews, name: String, on: Boolean, bgOn: Int, label: String? = null,
            idleIcon: Int = OFF_COLOR,
        ) {
            val box = id(v, "btn_$name")
            val icon = id(v, "ic_$name")
            val text = id(v, "lb_$name")
            v.setInt(box, "setBackgroundResource", if (on) bgOn else R.drawable.tile_off)
            v.setInt(icon, "setColorFilter", if (on) ON_COLOR else idleIcon)
            v.setTextColor(text, if (on) ON_COLOR else OFF_COLOR)
            if (label != null) v.setTextViewText(text, label)
        }

        private fun id(v: RemoteViews, name: String): Int =
            idOf(name)

        private fun idOf(name: String): Int = when (name) {
            "btn_normal" -> R.id.btn_normal; "ic_normal" -> R.id.ic_normal; "lb_normal" -> R.id.lb_normal
            "btn_silent" -> R.id.btn_silent; "ic_silent" -> R.id.ic_silent; "lb_silent" -> R.id.lb_silent
            "btn_loud" -> R.id.btn_loud; "ic_loud" -> R.id.ic_loud; "lb_loud" -> R.id.lb_loud
            "btn_mute" -> R.id.btn_mute; "ic_mute" -> R.id.ic_mute; "lb_mute" -> R.id.lb_mute
            "btn_bright" -> R.id.btn_bright; "ic_bright" -> R.id.ic_bright; "lb_bright" -> R.id.lb_bright
            "btn_live" -> R.id.btn_live; "ic_live" -> R.id.ic_live; "lb_live" -> R.id.lb_live
            "btn_air" -> R.id.btn_air; "ic_air" -> R.id.ic_air; "lb_air" -> R.id.lb_air
            "btn_loc" -> R.id.btn_loc; "ic_loc" -> R.id.ic_loc; "lb_loc" -> R.id.lb_loc
            "btn_bt" -> R.id.btn_bt; "ic_bt" -> R.id.ic_bt; "lb_bt" -> R.id.lb_bt
            else -> error("id tidak dikenal: $name")
        }

        private fun buildViews(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_volume)
            val active = VolumeController.activeMode(context)
            val live = ScreenLive.isOn(context)

            tile(v, "normal", active == VolumeMode.NORMAL, R.drawable.tile_normal_on)
            tile(v, "silent", active == VolumeMode.SILENT, R.drawable.tile_silent_on)
            tile(v, "loud", active == VolumeMode.LOUD, R.drawable.tile_loud_on)
            tile(v, "mute", active == VolumeMode.MUTE, R.drawable.tile_mute_on)
            // Kecerahan adalah aksi sekali ketuk, bukan status: ikon matahari selalu hangat.
            tile(v, "bright", false, R.drawable.tile_off, "${BrightnessController.targetPercent(context)}%", SUN_COLOR)
            tile(v, "live", live, R.drawable.tile_live_on)

            tile(v, "air", SystemStates.airplane(context), R.drawable.tile_live_on)
        tile(v, "loc", SystemStates.location(context), R.drawable.tile_live_on)
        tile(v, "bt", SystemStates.bluetooth(context), R.drawable.tile_live_on)
        v.setOnClickPendingIntent(R.id.btn_air, toggleIntent(context, "air", 11))
        v.setOnClickPendingIntent(R.id.btn_loc, toggleIntent(context, "loc", 12))
        v.setOnClickPendingIntent(R.id.btn_bt, toggleIntent(context, "bt", 13))
        v.setOnClickPendingIntent(R.id.btn_normal, modeIntent(context, VolumeMode.NORMAL, 1))
            v.setOnClickPendingIntent(R.id.btn_silent, modeIntent(context, VolumeMode.SILENT, 2))
            v.setOnClickPendingIntent(R.id.btn_loud, modeIntent(context, VolumeMode.LOUD, 3))
            v.setOnClickPendingIntent(R.id.btn_mute, modeIntent(context, VolumeMode.MUTE, 5))
            v.setOnClickPendingIntent(R.id.btn_bright, action(context, ACTION_BRIGHTNESS, 4))
            v.setOnClickPendingIntent(R.id.btn_live, action(context, ACTION_LIVE, 6))
            return v
        }

        private fun toggleIntent(context: Context, which: String, code: Int): PendingIntent =
        PendingIntent.getActivity(
            context, code,
            Intent(context, SystemToggleActivity::class.java).putExtra("which", which)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun modeIntent(context: Context, mode: VolumeMode, code: Int): PendingIntent {
            val i = Intent(context, VolumeWidgetProvider::class.java)
                .setAction(ACTION_MODE)
                .putExtra(EXTRA_MODE, mode.name)
            return broadcast(context, code, i)
        }

        private fun action(context: Context, action: String, code: Int): PendingIntent =
            broadcast(context, code, Intent(context, VolumeWidgetProvider::class.java).setAction(action))

        private fun broadcast(context: Context, code: Int, intent: Intent): PendingIntent =
            PendingIntent.getBroadcast(
                context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
    }
}
