package com.quickvolume.app

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.location.LocationManager
import android.os.Build
import android.provider.Settings

/** Status asli sistem Android (dibaca langsung, jadi selalu sinkron). */
object SystemStates {
    fun airplane(c: Context): Boolean =
        Settings.Global.getInt(c.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    @Suppress("DEPRECATION")
    fun location(c: Context): Boolean {
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else Settings.Secure.getInt(c.contentResolver, Settings.Secure.LOCATION_MODE, 0) != 0
    }

    @Suppress("DEPRECATION")
    fun bluetooth(c: Context): Boolean = try {
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    } catch (e: SecurityException) {
        false
    }
}
