package com.quickvolume.app

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/** Tile Pengaturan Cepat: ketuk untuk beralih antara Silent dan Normal. */
class VolumeTileService : TileService() {

    override fun onStartListening() {
        update()
    }

    override fun onClick() {
        val active = VolumeController.activeMode(this)
        val silent = active == VolumeMode.SILENT || active == VolumeMode.MUTE
        val result = VolumeController.applyTimed(this, if (silent) VolumeMode.NORMAL else VolumeMode.SILENT)
        Toast.makeText(applicationContext, result.message, Toast.LENGTH_SHORT).show()
        update()
    }

    private fun update() {
        val tile = qsTile ?: return
        val active = VolumeController.activeMode(this)
        tile.label = "Quick Volume"
        tile.state = if (active == VolumeMode.SILENT || active == VolumeMode.MUTE) {
            Tile.STATE_ACTIVE
        } else {
            Tile.STATE_INACTIVE
        }
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = active?.label ?: "Ketuk: Silent"
        tile.updateTile()
    }
}
