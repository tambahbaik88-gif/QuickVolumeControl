package com.quickvolume.app

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.roundToInt

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val context = LocalContext.current
            val scheme = when {
                Build.VERSION.SDK_INT >= 31 ->
                    if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) { SettingsScreen(onBack = { finish() }) }
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    // Naik setiap kali "Kembalikan ke bawaan" ditekan, supaya semua slider membaca ulang nilainya.
    var resetTick by remember { mutableIntStateOf(0) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val exactOk = tick >= 0 &&
        (Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms())

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        TextButton(onClick = onBack) { Text("← Kembali") }
        Text("Pengaturan", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        // Timer tombol
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Lama tombol bertahan", fontWeight = FontWeight.SemiBold)
                Text(
                    "Setelah tombol ditekan dan waktunya habis, pengaturan kembali otomatis. " +
                        "Pilih \"Tanpa batas\" agar bertahan sampai Anda ganti sendiri. " +
                        "Tombol Normal tidak punya timer karena ia adalah keadaan default.",
                    fontSize = 12.sp,
                )
                for (key in TimerKey.values()) DurationRow(ctx, key, resetTick)
                Text(
                    "Catatan: timer Kecerahan tidak berlaku saat Penjaga kecerahan aktif, " +
                        "karena penjaga selalu memaksa kecerahan tetap di target.",
                    fontSize = 12.sp,
                )
            }
        }

        // Tujuan kembali
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Setelah waktu habis, suara kembali ke", fontWeight = FontWeight.SemiBold)
                var revert by remember(resetTick) { mutableStateOf(QvcPrefs.revertMode(ctx)) }
                for (m in QvcPrefs.REVERT_CHOICES) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                revert = m
                                QvcPrefs.setRevertMode(ctx, m)
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = revert == m, onClick = null)
                        Text(m.label, Modifier.padding(start = 8.dp))
                    }
                }
                Text(
                    "Kecerahan kembali ke nilai sebelum tombol ditekan. " +
                        "Screen Live kembali ke batas waktu layar semula.",
                    fontSize = 12.sp,
                )
            }
        }

        LevelsCard(ctx, VolumeMode.NORMAL, "Level volume mode Normal", resetTick)
        LevelsCard(ctx, VolumeMode.LOUD, "Level volume mode Loud", resetTick)

        // Kecerahan
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                var b by remember(resetTick) {
                    mutableFloatStateOf(BrightnessController.targetPercent(ctx).toFloat())
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Target kecerahan", fontWeight = FontWeight.SemiBold)
                    Text("${b.roundToInt()}%", fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = b,
                    onValueChange = { b = it },
                    onValueChangeFinished = { BrightnessController.setTargetPercent(ctx, b.roundToInt()) },
                    valueRange = BrightnessController.MIN_PERCENT.toFloat()..BrightnessController.MAX_PERCENT.toFloat(),
                    steps = 15,
                )
            }
        }

        if (!exactOk) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Alarm tepat waktu", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Tanpa izin ini timer tetap jalan, tetapi bisa telat beberapa menit saat HP sedang tidur.",
                        fontSize = 12.sp,
                    )
                    OutlinedButton(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= 31) {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                        Uri.parse("package:${ctx.packageName}"),
                                    )
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Izinkan alarm tepat waktu") }
                }
            }
        }

        OutlinedButton(
            onClick = {
                QvcPrefs.resetAll(ctx)
                resetTick++
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Kembalikan semua ke bawaan") }
    }
}

@Composable
private fun DurationRow(ctx: Context, key: TimerKey, resetTick: Int) {
    val options = QvcPrefs.DURATION_OPTIONS
    var idx by remember(resetTick) {
        mutableFloatStateOf(options.indexOf(QvcPrefs.durationMinutes(ctx, key)).coerceAtLeast(0).toFloat())
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(key.label)
        Text(QvcPrefs.formatDuration(options[idx.roundToInt()]), fontWeight = FontWeight.Bold)
    }
    Slider(
        value = idx,
        onValueChange = { idx = it },
        onValueChangeFinished = { QvcPrefs.setDuration(ctx, key, options[idx.roundToInt()]) },
        valueRange = 0f..(options.size - 1).toFloat(),
        steps = options.size - 2,
    )
}

@Composable
private fun LevelsCard(ctx: Context, mode: VolumeMode, title: String, resetTick: Int) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            for (i in 0..3) {
                var v by remember(resetTick) { mutableFloatStateOf(QvcPrefs.levels(ctx, mode)[i].toFloat()) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(VolumeController.streams[i].first)
                    Text("${v.roundToInt()}%", fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = v,
                    onValueChange = { v = it },
                    onValueChangeFinished = {
                        QvcPrefs.setLevel(ctx, mode, i, (v / 5f).roundToInt() * 5)
                    },
                    valueRange = 0f..100f,
                    steps = 19,
                )
            }
        }
    }
}
