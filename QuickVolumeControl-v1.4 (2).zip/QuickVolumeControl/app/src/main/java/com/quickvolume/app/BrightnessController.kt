package com.quickvolume.app

import android.content.Context
import android.provider.Settings
import kotlin.math.roundToInt

object BrightnessController {
    const val MAX = 255
    const val DEFAULT_PERCENT = 50
    const val MIN_PERCENT = 10
    const val MAX_PERCENT = 90
    private const val KEY = "bright_target_pct"

    fun canWrite(context: Context) = Settings.System.canWrite(context)

    private fun prefs(c: Context) = c.getSharedPreferences("qvc", Context.MODE_PRIVATE)

    fun targetPercent(c: Context): Int =
        prefs(c).getInt(KEY, DEFAULT_PERCENT).coerceIn(MIN_PERCENT, MAX_PERCENT)

    fun setTargetPercent(c: Context, pct: Int) {
        prefs(c).edit().putInt(KEY, pct.coerceIn(MIN_PERCENT, MAX_PERCENT)).apply()
        VolumeWidgetProvider.refreshAll(c)
    }

    fun target(c: Context): Int = (targetPercent(c) * MAX / 100f).roundToInt()

    fun current(context: Context): Int = try {
        Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
    } catch (e: Settings.SettingNotFoundException) {
        target(context)
    }

    fun currentPercent(context: Context) = (current(context) * 100f / MAX).roundToInt()

    private fun currentMode(c: Context): Int =
        Settings.System.getInt(
            c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
        )

    /** Atur ke target lalu pasang timer untuk kembali ke kecerahan semula (sesuai pengaturan). */
    fun setTargetTimed(c: Context): ApplyResult {
        val minutes = QvcPrefs.durationMinutes(c, TimerKey.BRIGHT)
        val guardOn = BrightnessGuardService.isEnabled(c)
        val useTimer = minutes > 0 && !guardOn && canWrite(c)
        // Simpan kecerahan semula hanya sekali; tekan ulang saat timer jalan tidak menimpanya.
        if (useTimer && ModeTimer.endAt(c, ModeTimer.Kind.BRIGHT) == 0L) {
            prefs(c).edit()
                .putInt("prev_bright", current(c))
                .putInt("prev_bright_mode", currentMode(c))
                .apply()
        }
        val r = setTarget(c)
        if (!r.ok) return r
        if (!useTimer) {
            ModeTimer.cancel(c, ModeTimer.Kind.BRIGHT)
            return if (minutes > 0 && guardOn) {
                ApplyResult(true, "${r.message} Timer tidak berlaku saat Penjaga kecerahan aktif.")
            } else {
                r
            }
        }
        val end = ModeTimer.start(c, ModeTimer.Kind.BRIGHT, minutes)
        return ApplyResult(true, "${r.message} Kembali ke kecerahan semula pukul ${ModeTimer.clock(end)}.")
    }

    fun restorePrevious(c: Context): ApplyResult {
        if (!canWrite(c)) {
            return ApplyResult(false, "Kecerahan belum dikembalikan: izin ubah pengaturan sistem belum diberikan.")
        }
        val value = prefs(c).getInt("prev_bright", target(c)).coerceIn(1, MAX)
        val mode = prefs(c).getInt("prev_bright_mode", Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        return try {
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, mode)
            ApplyResult(true, "Kecerahan dikembalikan ke semula.")
        } catch (e: SecurityException) {
            ApplyResult(false, "Kecerahan ditolak oleh sistem.")
        }
    }

    fun setTarget(context: Context): ApplyResult {
        if (!canWrite(context)) {
            return ApplyResult(false, "Kecerahan belum diubah: izin ubah pengaturan sistem belum diberikan.")
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
            )
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, target(context))
            ApplyResult(true, "Kecerahan diatur ke ${targetPercent(context)}%.")
        } catch (e: SecurityException) {
            ApplyResult(false, "Kecerahan ditolak oleh sistem.")
        }
    }
}
