package com.quickvolume.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Timer "kembali ke default". Tiap jenis (suara, kecerahan, Screen Live) punya satu alarm;
 * waktu berakhirnya disimpan di preferensi supaya bisa dipasang ulang setelah restart.
 */
object ModeTimer {
    const val ACTION = "com.quickvolume.app.ACTION_TIMER"
    const val EXTRA_KIND = "kind"

    enum class Kind(val code: Int) { VOLUME(11), BRIGHT(12), LIVE(13) }

    private fun prefs(c: Context) = c.getSharedPreferences("qvc", Context.MODE_PRIVATE)

    private fun key(kind: Kind) = "timer_end_${kind.name}"

    /** Waktu berakhir (ms epoch), atau 0 jika tidak ada timer. */
    fun endAt(c: Context, kind: Kind): Long = prefs(c).getLong(key(kind), 0L)

    fun clock(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

    /** Mulai timer; mengembalikan waktu berakhir, atau 0 jika menit <= 0 (timer dibatalkan). */
    fun start(c: Context, kind: Kind, minutes: Int): Long {
        if (minutes <= 0) {
            cancel(c, kind)
            return 0L
        }
        val end = System.currentTimeMillis() + minutes * 60_000L
        prefs(c).edit().putLong(key(kind), end).apply()
        schedule(c, kind, end)
        return end
    }

    fun cancel(c: Context, kind: Kind) {
        c.getSystemService(AlarmManager::class.java).cancel(pending(c, kind))
        prefs(c).edit().remove(key(kind)).apply()
    }

    /** Pasang ulang alarm yang hilang (restart, update, force-stop); yang sudah lewat langsung dijalankan. */
    fun rescheduleAll(c: Context) {
        for (kind in Kind.values()) {
            val end = endAt(c, kind)
            if (end <= 0L) continue
            if (end <= System.currentTimeMillis()) {
                fire(c, kind)
            } else {
                schedule(c, kind, end)
            }
        }
    }

    /** Waktu habis: kembalikan pengaturan. Mengembalikan pesan untuk ditampilkan. */
    fun fire(c: Context, kind: Kind): String {
        prefs(c).edit().remove(key(kind)).apply()
        return when (kind) {
            Kind.VOLUME ->
                "Waktu habis. " + VolumeController.apply(c, QvcPrefs.revertMode(c)).message
            Kind.BRIGHT ->
                "Waktu habis. " + BrightnessController.restorePrevious(c).message
            Kind.LIVE ->
                if (ScreenLive.isOn(c)) "Waktu habis. " + ScreenLive.toggle(c).message else "Waktu habis."
        }
    }

    /** Baris ringkas timer yang sedang berjalan, untuk layar utama aplikasi. */
    fun summary(c: Context): List<String> {
        val out = mutableListOf<String>()
        val v = endAt(c, Kind.VOLUME)
        if (v > 0) out += "Suara kembali ke ${QvcPrefs.revertMode(c).label} pukul ${clock(v)}"
        val b = endAt(c, Kind.BRIGHT)
        if (b > 0) out += "Kecerahan kembali ke semula pukul ${clock(b)}"
        val l = endAt(c, Kind.LIVE)
        if (l > 0) out += "Screen Live mati otomatis pukul ${clock(l)}"
        return out
    }

    private fun schedule(c: Context, kind: Kind, end: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c, kind)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
        }
    }

    private fun pending(c: Context, kind: Kind): PendingIntent =
        PendingIntent.getBroadcast(
            c, kind.code,
            Intent(c, TimerReceiver::class.java).setAction(ACTION).putExtra(EXTRA_KIND, kind.name),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
}

/** Menerima alarm saat timer habis. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ModeTimer.ACTION) return
        val kind = ModeTimer.Kind.values().firstOrNull { it.name == intent.getStringExtra(ModeTimer.EXTRA_KIND) }
            ?: return
        val msg = ModeTimer.fire(context, kind)
        VolumeWidgetProvider.refreshAll(context)
        Toast.makeText(context.applicationContext, msg, Toast.LENGTH_LONG).show()
    }
}
