package com.quickvolume.app

import android.content.Context

/** Tombol yang bisa diberi timer. Normal tidak punya timer karena ia adalah keadaan default. */
enum class TimerKey(val label: String, val defaultMinutes: Int) {
    SILENT("Silent", 60),
    LOUD("Loud", 30),
    MUTE("Mute", 60),
    BRIGHT("Kecerahan", 30),
    LIVE("Screen Live", 30),
}

/** Semua pengaturan yang bisa diubah pengguna dari halaman Pengaturan. */
object QvcPrefs {
    /** Pilihan durasi (menit). 0 = tanpa batas (tidak kembali otomatis). */
    val DURATION_OPTIONS = listOf(0, 5, 10, 15, 30, 45, 60, 90, 120, 180, 240, 360, 480)

    /** Mode suara yang boleh dipilih sebagai tujuan "kembali ke". */
    val REVERT_CHOICES = listOf(VolumeMode.NORMAL, VolumeMode.SILENT, VolumeMode.LOUD)

    private fun p(c: Context) = c.getSharedPreferences("qvc", Context.MODE_PRIVATE)

    fun durationMinutes(c: Context, key: TimerKey): Int =
        p(c).getInt("dur_${key.name}", key.defaultMinutes)

    fun setDuration(c: Context, key: TimerKey, minutes: Int) {
        p(c).edit().putInt("dur_${key.name}", minutes).apply()
    }

    fun timerKeyFor(mode: VolumeMode): TimerKey? = when (mode) {
        VolumeMode.NORMAL -> null
        VolumeMode.SILENT -> TimerKey.SILENT
        VolumeMode.LOUD -> TimerKey.LOUD
        VolumeMode.MUTE -> TimerKey.MUTE
    }

    fun revertMode(c: Context): VolumeMode {
        val name = p(c).getString("revert_mode", null)
        return REVERT_CHOICES.firstOrNull { it.name == name } ?: VolumeMode.NORMAL
    }

    fun setRevertMode(c: Context, mode: VolumeMode) {
        p(c).edit().putString("revert_mode", mode.name).apply()
    }

    private fun defaultLevels(mode: VolumeMode) =
        intArrayOf(mode.media, mode.notification, mode.call, mode.alarm)

    /** Level volume (persen) mode: [media, notifikasi, panggilan, alarm]. Silent dan Mute selalu 0. */
    fun levels(c: Context, mode: VolumeMode): IntArray {
        val d = defaultLevels(mode)
        if (mode == VolumeMode.SILENT || mode == VolumeMode.MUTE) return d
        return IntArray(4) { p(c).getInt("vol_${mode.name}_$it", d[it]).coerceIn(0, 100) }
    }

    fun setLevel(c: Context, mode: VolumeMode, index: Int, pct: Int) {
        p(c).edit().putInt("vol_${mode.name}_$index", pct.coerceIn(0, 100)).apply()
    }

    fun resetAll(c: Context) {
        val ed = p(c).edit()
        for (k in TimerKey.values()) ed.remove("dur_${k.name}")
        ed.remove("revert_mode")
        for (m in listOf(VolumeMode.NORMAL, VolumeMode.LOUD)) {
            for (i in 0..3) ed.remove("vol_${m.name}_$i")
        }
        ed.apply()
        BrightnessController.setTargetPercent(c, BrightnessController.DEFAULT_PERCENT)
    }

    fun formatDuration(min: Int): String = when {
        min <= 0 -> "Tanpa batas"
        min < 60 -> "$min menit"
        min % 60 == 0 -> "${min / 60} jam"
        else -> "${min / 60} jam ${min % 60} mnt"
    }
}
