# Quick Volume Control
Cara build APK:
1. Android Studio: File > Open folder ini, tunggu sync, lalu Build > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk
2. Atau push ke GitHub; workflow "Build APK" menghasilkan artifact app-debug.apk.

## Versi 1.2
- Target kecerahan bisa diatur (slider 10–90%), tidak lagi tetap 50%.
- Penjaga kecerahan aktif lagi otomatis setelah restart dan disinkronkan saat app dibuka.
- Tile Pengaturan Cepat "Quick Volume" (ketuk: Silent <-> Normal).
- Tema terang/gelap + warna dinamis (Android 12+), tampilan edge-to-edge.
- Update dependensi: AGP 8.7.3, compileSdk/targetSdk 35, Compose BOM 2024.10.01.
- Perbaikan: widget tidak crash pada aksi tak dikenal, notifikasi penjaga membuka app, allowBackup dimatikan.

## Versi 1.3
- Widget didesain ulang: enam kartu seragam dengan ikon vektor (bukan emoji), warna aktif per mode, ukuran tetap sehingga tidak "melompat".
- Widget bisa diresize dan punya pratinjau di daftar widget (Android 12+).

## Versi 1.4: timer & pengaturan
- Tiap tombol (Silent, Loud, Mute, Kecerahan, Screen Live) bisa bertahan beberapa menit, lalu pengaturan kembali otomatis.
- Halaman **Pengaturan** (tombol "Pengaturan & timer" di layar utama aplikasi): durasi tiap tombol, tujuan kembali (Normal/Silent/Loud), level volume Normal & Loud, target kecerahan.
- Timer memakai AlarmManager dan dipasang ulang setelah restart/update. Izin "alarm tepat waktu" opsional agar akurat saat HP tidur.
